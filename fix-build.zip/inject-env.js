// inject-env.js — Roda durante o build do Vercel.
// Lê as variáveis de ambiente e gera o env-config.js com window.__ENV.

const fs = require('fs');
const path = require('path');

const keys = [
  'FIREBASE_API_KEY',
  'FIREBASE_AUTH_DOMAIN',
  'FIREBASE_PROJECT_ID',
  'FIREBASE_STORAGE_BUCKET',
  'FIREBASE_MESSAGING_SENDER_ID',
  'FIREBASE_APP_ID'
];

const missing = keys.filter(k => !process.env[k]);
if (missing.length) {
  console.error('[inject-env] ERRO: variáveis faltando:', missing.join(', '));
  console.error('[inject-env] Configure em: Vercel → Settings → Environment Variables');
  process.exit(1);
}

const envObj = {};
keys.forEach(k => { envObj[k] = process.env[k]; });

const content = `// Gerado automaticamente no build — NÃO EDITE e NÃO COMMITE este arquivo\nwindow.__ENV = ${JSON.stringify(envObj, null, 2)};\n`;

fs.writeFileSync(path.join(__dirname, 'env-config.js'), content, 'utf8');
console.log('[inject-env] env-config.js gerado com sucesso!');
keys.forEach(k => console.log(`  ${k}: ${process.env[k].slice(0, 8)}...`));
